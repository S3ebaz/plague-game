# Bitácora de Plagas

Sitio web para identificar plagas de grano almacenado, almacenes, molinos y cocinas.

**Página en vivo:** https://s3ebaz.github.io/plague-game/

## Archivos para GitHub Pages

- index.html — sitio completo (fichas, quiz, niveles, foto)
- sw.js — cache en el celular
- manifest.webmanifest — nombre e icono
- icon-192.png e icon-512.png
- README.md y .gitignore

Las fotos del catálogo van dentro de index.html.

## Publicar

1. https://github.com/S3ebaz/plague-game
2. Add file → Upload files
3. Sube el index.html nuevo y el resto
4. Commit a main
5. Settings → Pages → main / root

Sitio: https://s3ebaz.github.io/plague-game/

## Incluye

Nombre de jugador, insignias, Top 10 del mes, 10 niveles + 5 especiales, preguntas al azar, catálogo por sitio, productos Preserve e identificar por foto (recorte y contraste + fuentes CABI, FAO, SENASICA, Wikipedia).

Contenido educativo. Plaguicidas solo con personal autorizado.
